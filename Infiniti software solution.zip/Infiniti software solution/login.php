<?php
include("db.php");
?>
<!Doctype html>
<html>
	<head>
		<title> Login Page </title>
	</head>
<style>
*{
	 font-family:poppins,-apple-system,BlinkMacSystemFont,segoe ui,Roboto,helvetica neue,Arial,sans-serif;
	 margin:0px;
}
#hr1{
	height:6px;
	background-color:#756AEE;
}
#head{
margin-bottom:5px;
width:100%;
height:100px;
background-image: url("img/download.png");
background-repeat: no-repeat;
background-color:white;	
}
nav{
padding-left:350px;
margin-bottom:10px
}
#ol1{
	margin-left:12em;
}
#ol1 li{
margin-top:45px;
display:inline-block;
width:140px;
text-align:center;
font-size:14px;
font-weight:bold;
margin-bottom:0px;
}
#dv1{
	background-color:white;
	margin-top:140px;
	margin-left:400px;
	width:40%;
    border:1px solid #EAEAEA; box-shadow:0 0 13px -4px rgba(0,0,0,.17);	
}
.btn1{
	background-color:#756AEE;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;	
  margin-bottom:25px;
}
</style>
	<hr id=hr1>
<header id=head>
<nav>
<ol id=ol1>
			<li><a href="index.php">Home</li></a>
			<li><a href="infiblog.php">Infinity Blog</li></a>
			<li><a href="login.php">Admin Panel</li></a>
			<li><a href="contactus.php">Contact Us</li></a>
			<li><a href="aboutus.php">About Us</li></a>
</ol>
</nav>
</header>
<body style="background-color:#756AEE">
	<div id=dv1>
			<center>
<h1 style ="font_waight:bold"><span style="color:#756AEE">  ADMIN LOGIN PANEL</span></h1>
			
			<br>
			<br>
			<form action="" method="POST">
		UserName&nbsp&nbsp<input type ="text" name ="user" class="form-control" id= a style="width:300px;height:25px;border:2px solid #EAEAEA; box-shadow:0 0 13px -4px rgba(0,0,0,.17);" placeholder ="Enter User Name">
			<br><br>
			Password &nbsp &nbsp<input type ="password" name ="pass" class="form-control" id=b style="width:300px;height:25px;border:2px solid #EAEAEA; box-shadow:0 0 13px -4px rgba(0,0,0,.17);	" placeholder ="Enter Password">
			<br><br>
			<button name=sub class="btn1"> LOGIN</button>
			</form>
			<?php
					if(isset($_POST['sub']))
					{
						$user=$_POST['user'];
						
						$pass=$_POST['pass'];
						
						
						
						$in ="select * from admin where user='$user' AND pass='$pass'";
						$run=mysqli_query($con,$in);
						
						if($run)
							
						{
							echo "<script>window.open('admin.php','_self')</script>";
							
						}
						else
						{
							echo "<h5> User name or password is wrong</h5>";
						}
						
					}
			?>
			</center>
		<div>	
	</body>
	</html> 