<html>
<head><title>Infinity Blog</title></head>
<style>
*{
	 font-family:poppins,-apple-system,BlinkMacSystemFont,segoe ui,Roboto,helvetica neue,Arial,sans-serif;
	 margin:0px;
}
#hr1{
	height:6px;
	background-color:#756AEE;
}
#head{
margin-bottom:5px;
width:100%;
height:100px;
background-image: url("img/download.png");
background-repeat: no-repeat;
}
nav{
padding-left:350px;
margin-bottom:10px
}
#ol1{
	margin-left:12em;
}
#ol1 li{
margin-top:45px;
display:inline-block;
width:140px;
text-align:center;
font-size:14px;
font-weight:bold;
margin-bottom:0px;
}
#dv1{
	height:65px;
	background-color:#756AEE;
	margin-bottom:20px;
	margin-top:20px;
}
#h1{
	color:white;
	position:relative;
	padding-top:18px;
	padding-left:40px;
	word-spacing:2px;
	letter-spacing:5px;
}
#p1{
	color:green;
	margin-bottom:20px;
	margin-left:150px;
}
.dv2{
	width:70%;
	height:60%;
	border:1.5px solid #EAEAEA;
	margin-left:200px;
	margin-bottom:25px;
}
.img{
	padding:2px 2px 2px 2px;
	width:49%;
	height:99%;
}
#dv3{
	width:100%;
	height:48%;
	background-color:#D12635;
}
#h2{
	color:white;
	font-size:40px;
	padding-top:20px;
	text-align:center;
	padding-bottom:20px;
}
#p2{
	color:white;
	text-align:justify;
	padding-left:300px;
	width:48em;
}
#btn1{
	
  background-color:white;
  border: none;
  color:#D12635	;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  position:relative;
  top:30px;
  left:560px;	
}
#dv4{
	width:100%;
	height:25%;
	background-color:#093142;
}
#h3{
	width:8em;
	padding-left:160px;
	padding-top:60px;
}
#dv5{
	width:50%;
	padding-left:550px;
	margin-top:-50px;
}
#iem{
	width:250px;
	height:40px;
	
}
#btn2{
	
  background-color:white;
  border: none;
  color:#D12635	;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  position:relative;
  top:-2px;
  left:60px;	
}
#hr2{
	height:6px;
	background-color:#756AEE;
	margin-bottom:20px;
}
#par{
	color:#9B9B9B;
	margin-bottom:20px;
	text-align:center;
}
#hr3{
	height:6px;
	background-color:#756AEE;
	margin-bottom:0px;
}
#pre{
	text-align:center;
	margin-bottom:10px;
}
#dv6{
	align:center;
	margin-left:580px;
}
.fimg{
	padding-right:20px;
	width:30px;
}
</style>
<body>
<hr id=hr1>
<header id=head>
<nav>
<ol id=ol1>
			<li><a href="index.php">Home</li></a>
			<li><a href="infiblog.php">Infiniti Blog</li></a>
			<li><a href="login.php">Admin Panel</li></a>
			<li><a href="contactus.php">Contact Us</li></a>
			<li><a href="aboutus.php">About Us</li></a>
</ol>
</nav>
</header>
<div id=dv1>
<h2 id=h1>Life At Infiniti</h2>
</div>
<p id=p1>All Post</p>
<div class=dv2>
<img src="img/img.jpg" class=img>
<img src="img/img3.jpg" class=img>
</div>
<div class=dv2>
<img src="img/img1.jpg" class=img>
<img src="img/img.5.jpeg" class=img>
</div>
<div class=dv2>
<img src="img/img2.jpg" class=img>
<img src="img/img.6.jpg" class=img>
</div>

<div id=dv3>
<h2 id=h2>Be The Difference.!</h2>
<p id=p2>Infiniti promotes the idea of #bethedifference and welcomes ideas from all its employees.
 Infiniti celebrates the success of each employee , this drives them to go for that extra mile to deliver the best.
 The passion and determination of our team to make a difference have made us one of the pioneer in the travel industry.
</p>
<input type=button value="Join us" id="btn1">
</div>

<div id=dv4>
 <h2 id=h3>SIGN UP AND STAY UPDATED!</h2>
 <div id=dv5>
 Email&nbsp &nbsp<input type=text id=iem placeholder="Enter your mail id">
 <input type=button value="Subscribe" id="btn2">
 </div>
</div>
<footer>
<hr id=hr2>
<pre id=pre>Business Travel | Expence Management | Revenue Management | Forecasting Tool | Airline SME Solution </pre>
<div id=dv6> 
	<a href="https://www.facebook.com/Infiniti.Atyourprice?ref=hl" target="_blank" rel="noopener"><img  src="img/fb1.png" class=fimg  alt="Facebook" title="facebook"></a>
	<a href="https://twitter.com/Infiniti_Soft" target="_blank" rel="noopener"><img src="img/tw.png" class=fimg alt="Twitter" title="Twitter"></a>
	<a href="https://www.linkedin.com/company/761319?trk=tyah&trkInfo=clickedVertical%3Acompany%2Cidx%3A2-1-2%2CtarId%3A1431329332776%2Ctas%3Ainfiniti%20software" target="_blank" rel="noopener"><img src="img/in.png" class=fimg  alt="LinkedIn" title="LinkedIn"></a>
	<a href="https://twitter.com/Infiniti_Soft" target="_blank" rel="noopener"><img src="img/yt.png" class=fimg alt="You tube" title="You Tube"></a>
</div>
<p id=par>&copy; Copyrights of 2019 Infiniti Software Solution Pvt Ltd. | designed by Naveen</p>
<hr id=hr3>
</footer>
</body>
</html>
</html>