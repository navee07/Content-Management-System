<html>
<head><title>Contact Us</title></head>
<style>
*{
	 font-family:poppins,-apple-system,BlinkMacSystemFont,segoe ui,Roboto,helvetica neue,Arial,sans-serif;
	 margin:0px;
}
#hr1{
	height:6px;
	background-color:#756AEE;
}
#head{
margin-bottom:5px;
width:100%;
height:100px;
background-image: url("img/download.png");
background-repeat: no-repeat;
}
nav{
padding-left:350px;
margin-bottom:10px
}
#ol1{
	margin-left:12em;
}
#ol1 li{
margin-top:45px;
display:inline-block;
width:140px;
text-align:center;
font-size:14px;
font-weight:bold;
margin-bottom:0px;
}
#dv1{
	height:65px;
	background-color:#756AEE;
	margin-bottom:20px;
	margin-top:20px;
}
#h1{
	color:white;
	position:relative;
	padding-top:10px;
	padding-left:40px;
	word-spacing:2px;
	letter-spacing:5px;
}
#dv2{
	width:50%;
	height:300px;
	padding-left:40px;
	position:relative;
	margin-left:90px;
	margin-top:60px;
}
#btn1{
	background-color:#756AEE;
  border: none;
  color: white;
  padding: 7.5px 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 2px 2px;
  cursor: pointer;
  	
}
#dv3{
	padding:40px 20px 40px 40px;
width:48%;
height:300px;
margin-left:550px;
margin-top:-320px;
border:1px solid red;
border:2px solid #EAEAEA; 
box-shadow:0 0 13px -4px rgba(0,0,0,.17);
margin-bottom:20px;	
}
#imgphn{
	margin-top:20px;
	padding-right:30px;
	padding-bottom:30px;
	width:180px;
	height:100px;
	
}
#dv4{
	margin-left:70px;
    width:90%;	
}
#dv5{
	margin-left:70px;
    width:90%;	
}
#hr2{
	height:6px;
	background-color:#756AEE;
	margin-bottom:20px;
}
#par{
	color:#9B9B9B;
	margin-bottom:20px;
	text-align:center;
}
#hr3{
	height:6px;
	background-color:#756AEE;
	margin-bottom:0px;
}
#pre{
	text-align:center;
	margin-bottom:10px;
}
#dv6{
	align:center;
	margin-left:580px;
}
.fimg{
	padding-right:20px;
	width:30px;
}
</style>
<body>
<hr id=hr1>
<header id=head>
<nav>
<ol id=ol1>
			<li><a href="index.php">Home</li></a>
			<li><a href="infiblog.php">Infiniti Blog</li></a>
			<li><a href="login.php">Admin Panel</li></a>
			<li><a href="contactus.php">Contact Us</li></a>
			<li><a href="aboutus.php">About Us</li></a>
</ol>
</nav>
</header>
<div id=dv1>
<h1 id=h1>Contact Us</h1>
</div>
<div id=dv2>
Name<br><br><input type=text style="width:300px;height:35px;border:2px solid #EAEAEA; box-shadow:0 0 13px -4px rgba(0,0,0,.17);" placeholder ="Enter your Name">
<br><br>
Email<br><br><input type=email style="width:300px;height:35px;border:2px solid #EAEAEA; box-shadow:0 0 13px -4px rgba(0,0,0,.17);" placeholder ="Enter your MailID">
<br><br>
Message<br><br><textarea name="comment" style="width:300px;height:50px;border:2px solid #EAEAEA; box-shadow:0 0 13px -4px rgba(0,0,0,.17);"placeholder ="Enter your Message"></textarea>
<br><br>
<input type=button value=Submit id=btn1>
</div>
<div id=dv3>
<img src="img/Agency-Auto-Icon.png" id=imgphn >
<img src="img/price.png" id=imgphn >
<img src="img/GroupRm.png" id=imgphn >
<img src="img/expen.jpg" id=imgphn >
<img src="img/Craft.png" id=imgphn >
<img src="img/SME.png" id=imgphn >
</div>
<br>
<br>
<div id=dv4>
<h4>Partnership opportunity</h4>
<br>
<p>Infiniti's Resellers are a critical part of our business, supplying to and supporting our mutual clients 
at a local level, giving that personal experience. Specializing on a focused skill set, and typically delivering within 
specific verticals or industries, our Reseller partners add value by providing consulting, integration, 
implementation services, and even 1st line support to supplement their portfolio and product margins.<p><br>
<p>Our Resellers will receive the following benefits:</p><br>
<ol>
			<li>Access to technical guidance and expertise from Infiniti</li>
			<li>Enhance brand perception and create additional annuity models to increase revenue</li>
			<li>Access to Partner Portal</li>
			<li>Deal Registration Program</li>
			<li>Featured on vendor website</li>
			<li>For any partnership proposal, please contact gautam@atyourprice.in
</li>
</ol>
</div>
<br><br>
<div id=dv5>
<iframe width="100%" height="300" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;coord=13.057510599999999,80.25378529999999&amp;q=No.84%2C%201st%20Floor%2C%20Murugesan%20Naicker%20Building%2C%20%20Greams%20Road%2C%20Thousand%20Lights%2C%20Chennai%20-%20600%20006+(Infiniti%20Software%20Solutions)&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" 
frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
</div>
<br>
<br>
<footer>
<hr id=hr2>
<pre id=pre>Business Travel | Expence Management | Revenue Management | Forecasting Tool | Airline SME Solution </pre>
<div id=dv6> 
	<a href="https://www.facebook.com/Infiniti.Atyourprice?ref=hl" target="_blank" rel="noopener"><img  src="img/fb1.png" class=fimg  alt="Facebook" title="facebook"></a>
	<a href="https://twitter.com/Infiniti_Soft" target="_blank" rel="noopener"><img src="img/tw.png" class=fimg alt="Twitter" title="Twitter"></a>
	<a href="https://www.linkedin.com/company/761319?trk=tyah&trkInfo=clickedVertical%3Acompany%2Cidx%3A2-1-2%2CtarId%3A1431329332776%2Ctas%3Ainfiniti%20software" target="_blank" rel="noopener"><img src="img/in.png" class=fimg  alt="LinkedIn" title="LinkedIn"></a>
	<a href="https://twitter.com/Infiniti_Soft" target="_blank" rel="noopener"><img src="img/yt.png" class=fimg alt="You tube" title="You Tube"></a>
</div>
<p id=par>&copy; Copyrights of 2019 Infiniti Software Solution Pvt Ltd. | designed by Naveen</p>
<hr id=hr3>
</footer>
</body>