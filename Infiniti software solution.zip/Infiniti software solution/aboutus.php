<html>
<head><title>About Us</title></head>
<style>
*{
	 font-family:poppins,-apple-system,BlinkMacSystemFont,segoe ui,Roboto,helvetica neue,Arial,sans-serif;
	 margin:0px;
}
#hr1{
	height:6px;
	background-color:#756AEE;
}
#head{
margin-bottom:5px;
width:100%;
height:100px;
background-image: url("img/download.png");
background-repeat: no-repeat;
}
nav{
padding-left:350px;
margin-bottom:10px
}
#ol1{
	margin-left:12em;
}
#ol1 li{
margin-top:45px;
display:inline-block;
width:140px;
text-align:center;
font-size:14px;
font-weight:bold;
margin-bottom:0px;
}
#dv1{
	height:65px;
	background-color:#756AEE;
	margin-bottom:20px;
	margin-top:20px;
}
#h1{
	color:white;
	position:relative;
	padding-top:10px;
	padding-left:40px;
	word-spacing:2px;
	letter-spacing:5px;
}
#dv2{
	width:70em;
	margin-left:100px;
}
#dv3{
width:50%px;
margin-left:100px;	
margin-bottom:20px;
}
#imgphn{
	margin-top:20px;
	padding-right:20px;
	width:180px;
	height:100px;
	margin-bottom:20px;
}
#hr2{
	height:6px;
	background-color:#756AEE;
	margin-bottom:20px;
}
#par{
	color:#9B9B9B;
	margin-bottom:20px;
	text-align:center;
}
#hr3{
	height:6px;
	background-color:#756AEE;
	margin-bottom:0px;
}
#pre{
	text-align:center;
	margin-bottom:10px;
}
#dv4{
	align:center;
	margin-left:580px;
}
.fimg{
	padding-right:20px;
	width:30px;
}
</style>
<body>
<hr id=hr1>
<header id=head>
<nav>
<ol id=ol1>
			<li><a href="index.php">Home</li></a>
			<li><a href="infiblog.php">Infiniti Blog</li></a>
			<li><a href="login.php">Admin Panel</li></a>
			<li><a href="contactus.php">Contact Us</li></a>
			<li><a href="contact.php">About Us</li></a>
</ol>
</nav>
</header>
<div id=dv1>
<h1 id=h1>About Us</h1>
</div>
<div id=dv2>
<p>"Never doubt that a small group of thoughtful, committed people can change the world. 
Indeed, it is the only thing that ever has." - Margaret Meade<br><br>
Our endeavor has been to create world class travel and aviation technology solutions. We believe in building 
strong partnerships with our customers to ensure that we are able to deliver a robust and cost efficient solution to them.<br><br>
Our journey has been an exciting and rewarding one. We pride ourselves in developing innovative travel technology products,
 from building India`s first retail travel portal Ghumo.com to India`s first web based business travel solution 
 Atyouprice.net, our mission has remained unchanged.<br><br>We are fortunate to have an opportunity to serve over 230 
 corporates , travel agencies and airlines across the globe. Today Team Infiniti is spread across four locations in India
 with over 250 highly motivated and experienced travel technology specialists supporting our vision and customers.<br><br></p>
 <br>
 <h3>Our Investors</h3>
 <br>
 <p>Infiniti is funded by Mumbai Angels<span style="color:blue;"> (www.mumbaiangels.com)</span>, a group of experienced professionals-turned-investors.
 Mumbai Angels, which has as its members CEOs, CFOs, senior lawyers and IT experts with experience in Silicon Valley,
 California, backs start-ups and young companies.</p><br><br>
 <h4>Investor Relations</h4><br>
 <p>Gautam Ramanujan<br> 
Chief Commercial Officer <br>
9920984120 | <span style="color:blue;">gautam@infinitisoftware.net</span></p><br><br>
</div>
<div id=dv3>
<img src="img/Agency-Auto-Icon.png" id=imgphn >
<img src="img/price.png" id=imgphn >
<img src="img/GroupRm.png" id=imgphn >
<img src="img/expen.jpg" id=imgphn >
<img src="img/Craft.png" id=imgphn >
<img src="img/SME.png" id=imgphn >
</div>
<footer>
<hr id=hr2>
<pre id=pre>Business Travel | Expence Management | Revenue Management | Forecasting Tool | Airline SME Solution </pre>
<div id=dv4> 
	<a href="https://www.facebook.com/Infiniti.Atyourprice?ref=hl" target="_blank" rel="noopener"><img  src="img/fb1.png" class=fimg  alt="Facebook" title="facebook"></a>
	<a href="https://twitter.com/Infiniti_Soft" target="_blank" rel="noopener"><img src="img/tw.png" class=fimg alt="Twitter" title="Twitter"></a>
	<a href="https://www.linkedin.com/company/761319?trk=tyah&trkInfo=clickedVertical%3Acompany%2Cidx%3A2-1-2%2CtarId%3A1431329332776%2Ctas%3Ainfiniti%20software" target="_blank" rel="noopener"><img src="img/in.png" class=fimg  alt="LinkedIn" title="LinkedIn"></a>
	<a href="https://twitter.com/Infiniti_Soft" target="_blank" rel="noopener"><img src="img/yt.png" class=fimg alt="You tube" title="You Tube"></a>
</div>
<p id=par>&copy; Copyrights of 2019 Infiniti Software Solution Pvt Ltd. | designed by Naveen</p>
<hr id=hr3>
</footer>
</body>
</html>
</html>
</div>
</body>